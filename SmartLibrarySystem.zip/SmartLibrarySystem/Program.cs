using System;
using SmartLibrarySystem.Models;
using SmartLibrarySystem.Services;

namespace SmartLibrarySystem;

class Program
{
    static LibraryService _libraryService = new LibraryService();

    static void Main(string[] args)
    {
        while (true)
        {
            Console.Clear();
            Console.WriteLine("=== Smart Library Management System ===");
            Console.WriteLine("1. Book Management");
            Console.WriteLine("2. Member Management");
            Console.WriteLine("3. Issue Book");
            Console.WriteLine("4. Return Book");
            Console.WriteLine("5. Reports");
            Console.WriteLine("6. Exit");
            Console.Write("Select an option: ");

            var choice = Console.ReadLine();

            try
            {
                switch (choice)
                {
                    case "1": BookManagementMenu(); break;
                    case "2": MemberManagementMenu(); break;
                    case "3": IssueBook(); break;
                    case "4": ReturnBook(); break;
                    case "5": ReportsMenu(); break;
                    case "6": return;
                    default: Console.WriteLine("Invalid choice. Try again."); break;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error: {ex.Message}");
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }
    }

    static void BookManagementMenu()
    {
        Console.Clear();
        Console.WriteLine("--- Book Management ---");
        Console.WriteLine("1. Add Book");
        Console.WriteLine("2. View All Books");
        Console.WriteLine("3. Search Book");
        Console.Write("Select an option: ");
        var choice = Console.ReadLine();

        switch (choice)
        {
            case "1":
                Console.Write("Title: ");
                var title = Console.ReadLine();
                Console.Write("Author: ");
                var author = Console.ReadLine();
                Console.Write("ISBN: ");
                var isbn = Console.ReadLine();
                Console.Write("Category: ");
                var category = Console.ReadLine();
                Console.Write("Total Copies: ");
                if (!int.TryParse(Console.ReadLine(), out int totalCopies) || totalCopies <= 0)
                {
                    Console.WriteLine("Invalid copies number.");
                    return;
                }

                if (string.IsNullOrWhiteSpace(title) || string.IsNullOrWhiteSpace(author) || string.IsNullOrWhiteSpace(isbn))
                {
                    Console.WriteLine("Fields cannot be empty.");
                    return;
                }

                var book = new Book { Title = title, Author = author, ISBN = isbn, Category = category, TotalCopies = totalCopies };
                _libraryService.AddBook(book);
                Console.WriteLine("Book added successfully.");
                break;
            case "2":
                var books = _libraryService.GetAllBooks();
                foreach (var b in books)
                {
                    Console.WriteLine($"ID: {b.BookId}, Title: {b.Title}, Author: {b.Author}, ISBN: {b.ISBN}, Available: {b.AvailableCopies}/{b.TotalCopies}");
                }
                break;
            case "3":
                Console.Write("Enter search query: ");
                var query = Console.ReadLine();
                var results = _libraryService.SearchBooks(query);
                foreach (var b in results)
                {
                    Console.WriteLine($"ID: {b.BookId}, Title: {b.Title}, Author: {b.Author}");
                }
                break;
            default:
                Console.WriteLine("Invalid option.");
                break;
        }
    }

    static void MemberManagementMenu()
    {
        Console.Clear();
        Console.WriteLine("--- Member Management ---");
        Console.WriteLine("1. Register Member");
        Console.WriteLine("2. View All Members");
        Console.Write("Select an option: ");
        var choice = Console.ReadLine();

        switch (choice)
        {
            case "1":
                Console.Write("Name: ");
                var name = Console.ReadLine();
                Console.Write("Phone: ");
                var phone = Console.ReadLine();
                Console.Write("Email: ");
                var email = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(name) || string.IsNullOrWhiteSpace(email) || !email.Contains("@"))
                {
                    Console.WriteLine("Invalid input. Name is required and Email must contain '@'.");
                    return;
                }

                var member = new Member { Name = name, Phone = phone, Email = email };
                _libraryService.RegisterMember(member);
                Console.WriteLine("Member registered successfully.");
                break;
            case "2":
                var members = _libraryService.GetAllMembers();
                foreach (var m in members)
                {
                    Console.WriteLine($"ID: {m.MemberId}, Name: {m.Name}, Email: {m.Email}, Borrowed: {m.BorrowedBooksCount}");
                }
                break;
            default:
                Console.WriteLine("Invalid option.");
                break;
        }
    }

    static void IssueBook()
    {
        Console.Clear();
        Console.WriteLine("--- Issue Book ---");
        Console.Write("Enter Book ID: ");
        if (!int.TryParse(Console.ReadLine(), out int bookId))
        {
            Console.WriteLine("Invalid Book ID.");
            return;
        }

        Console.Write("Enter Member ID: ");
        if (!int.TryParse(Console.ReadLine(), out int memberId))
        {
            Console.WriteLine("Invalid Member ID.");
            return;
        }

        _libraryService.IssueBook(bookId, memberId);
        Console.WriteLine("Book issued successfully.");
    }

    static void ReturnBook()
    {
        Console.Clear();
        Console.WriteLine("--- Return Book ---");
        Console.Write("Enter Issue ID: ");
        if (!int.TryParse(Console.ReadLine(), out int issueId))
        {
            Console.WriteLine("Invalid Issue ID.");
            return;
        }

        var fine = _libraryService.ReturnBook(issueId);
        Console.WriteLine("Book returned successfully.");
        if (fine > 0)
        {
            Console.WriteLine($"Late return. Fine calculated: ${fine}");
        }
    }

    static void ReportsMenu()
    {
        Console.Clear();
        Console.WriteLine("--- Reports ---");
        Console.WriteLine("1. Books Report");
        Console.WriteLine("2. Members Report");
        
        var choice = Console.ReadLine();
        if (choice == "1")
        {
            Console.WriteLine("Total Books: " + _libraryService.GetAllBooks().Count);
        }
        else if (choice == "2")
        {
            Console.WriteLine("Total Members: " + _libraryService.GetAllMembers().Count);
        }
    }
}
