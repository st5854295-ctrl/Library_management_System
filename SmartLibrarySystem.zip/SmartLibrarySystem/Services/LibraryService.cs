using System;
using System.Collections.Generic;
using System.Linq;
using SmartLibrarySystem.Models;
using SmartLibrarySystem.Data;

namespace SmartLibrarySystem.Services;

public class LibraryService
{
    private const string BooksFile = "books.json";
    private const string MembersFile = "members.json";
    private const string TransactionsFile = "transactions.json";

    private List<Book> _books;
    private List<Member> _members;
    private List<IssueRecord> _transactions;

    public LibraryService()
    {
        _books = FileStorage.LoadData<Book>(BooksFile);
        _members = FileStorage.LoadData<Member>(MembersFile);
        _transactions = FileStorage.LoadData<IssueRecord>(TransactionsFile);
    }

    private void SaveBooks() => FileStorage.SaveData(BooksFile, _books);
    private void SaveMembers() => FileStorage.SaveData(MembersFile, _members);
    private void SaveTransactions() => FileStorage.SaveData(TransactionsFile, _transactions);

    // Book Management
    public void AddBook(Book book)
    {
        if (_books.Any(b => b.ISBN == book.ISBN))
        {
            throw new InvalidOperationException("A book with this ISBN already exists.");
        }
        
        book.BookId = _books.Any() ? _books.Max(b => b.BookId) + 1 : 1;
        book.AvailableCopies = book.TotalCopies;
        _books.Add(book);
        SaveBooks();
    }

    public List<Book> GetAllBooks() => _books;

    public List<Book> SearchBooks(string query)
    {
        return _books.Where(b => b.Title.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                                 b.Author.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                                 b.ISBN.Contains(query)).ToList();
    }

    // Member Management
    public void RegisterMember(Member member)
    {
        member.MemberId = _members.Any() ? _members.Max(m => m.MemberId) + 1 : 1;
        member.BorrowedBooksCount = 0;
        _members.Add(member);
        SaveMembers();
    }

    public List<Member> GetAllMembers() => _members;

    // Issue and Return
    public void IssueBook(int bookId, int memberId)
    {
        var book = _books.FirstOrDefault(b => b.BookId == bookId);
        if (book == null) throw new InvalidOperationException("Book not found.");
        
        var member = _members.FirstOrDefault(m => m.MemberId == memberId);
        if (member == null) throw new InvalidOperationException("Member not found.");

        if (book.AvailableCopies <= 0)
            throw new InvalidOperationException("Book is currently unavailable.");

        if (member.BorrowedBooksCount >= 3)
            throw new InvalidOperationException("Member has already borrowed the maximum limit of 3 books.");

        var issueId = _transactions.Any() ? _transactions.Max(t => t.IssueId) + 1 : 1;

        var record = new IssueRecord
        {
            IssueId = issueId,
            BookId = bookId,
            MemberId = memberId,
            IssueDate = DateTime.Now,
            DueDate = DateTime.Now.AddDays(14), // Default 14 days borrowing period
            Status = "Issued"
        };

        book.AvailableCopies--;
        member.BorrowedBooksCount++;
        _transactions.Add(record);
        
        SaveBooks();
        SaveMembers();
        SaveTransactions();
    }

    public decimal ReturnBook(int issueId)
    {
        var record = _transactions.FirstOrDefault(t => t.IssueId == issueId && t.Status == "Issued");
        if (record == null) throw new InvalidOperationException("Issue record not found or book already returned.");

        record.ReturnDate = DateTime.Now;
        record.Status = "Returned";

        var lateDays = (record.ReturnDate.Value.Date - record.DueDate.Date).Days;
        if (lateDays > 0)
        {
            record.FineAmount = lateDays * 5; // Fine = LateDays * 5
        }

        var book = _books.FirstOrDefault(b => b.BookId == record.BookId);
        if (book != null) book.AvailableCopies++;

        var member = _members.FirstOrDefault(m => m.MemberId == record.MemberId);
        if (member != null) member.BorrowedBooksCount--;

        SaveBooks();
        SaveMembers();
        SaveTransactions();

        return record.FineAmount;
    }
}
